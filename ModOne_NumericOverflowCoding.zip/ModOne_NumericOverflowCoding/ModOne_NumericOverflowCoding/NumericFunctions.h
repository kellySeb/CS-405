#ifndef NUMERICFUNCTIONS_H
#define NUMERICFUNCTIONS_H

#include <limits> 
#include <type_traits>

/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to add each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start + (increment * steps) or a special value indicating overflow</returns>
template <typename T>
T add_numbers(T const& start, T const& increment, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Check for overflow for integer types
        if (std::numeric_limits<T>::is_integer)
        {
            if (result > std::numeric_limits<T>::max() - increment)
            {
                // Indicate overflow by returning the maximum possible value
                return std::numeric_limits<T>::max();
            }
        }
        else
        {
            // Check for overflow for floating-point types
            if (result + increment > std::numeric_limits<T>::max())
            {
                // Indicate overflow by returning infinity
                return std::numeric_limits<T>::infinity();
            }
        }
        result += increment;
    }

    return result;
}

/// <summary>
/// Template function to abstract away the logic of:
///   start - (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to subtract each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start - (increment * steps) or a special value indicating underflow</returns>
template <typename T>
T subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Check for underflow for integer types
        if (std::numeric_limits<T>::is_integer)
        {
            if (std::is_unsigned<T>::value)
            {
                if (result < decrement)
                {
                    // Indicate underflow by returning zero for unsigned type
                    return 0;
                }
            }
            else
            {
                if (result < std::numeric_limits<T>::min() + decrement)
                {
                    // Indicate underflow by returning the minimum possible value
                    return std::numeric_limits<T>::min();
                }
            }
        }
        else
        {
            // Check for underflow for floating-point types
            if (result - decrement < std::numeric_limits<T>::lowest())
            {
                // Indicate underflow by returning the lowest possible value
                return std::numeric_limits<T>::lowest();
            }
        }
        result -= decrement;
    }

    return result;
}

#endif // NUMERICFUNCTIONS_H
